//
//  SpineIndicator.swift
//  Biofeedback Posture Chair
//
//  Created by Micah Reid on 10/21/16.
//  Copyright © 2016 Micah Reid. All rights reserved.
//

import Foundation
import UIKit

class SpineIndicator: UIView{
    let red = [255,0,0]
    let yellow = [255,328,0]
    let green = [27,217,68]
    var value = 0.0
    var color = UIColor.black
    override func draw(_ rect: CGRect) {

        print("value: " + String(value))
        if(value < 400){
            //red-yellow
            color = UIColor(colorLiteralRed: 255 , green: Float(red[1] - yellow[1]) * Float(Int(value)) / 400 + Float(red[1]), blue: 0, alpha: 1)
            //color = UIColor.blue
        }
        if(value > 400){
            //yellow-green
            var newColor = [0.0,0.0,0.0]
            newColor[0] = Double(green[0] - yellow[0]) * value / 400.0 + Double(green[0])
            newColor[1] = Double(green[1] - yellow[1]) * value / 400.0 + Double(green[1])
            newColor[2] = Double(green[2] - yellow[2]) * Double(value) / 400.0 + Double(green[2])
            color = UIColor(colorLiteralRed: Float(newColor[0]) , green: Float(newColor[1]) , blue: Float(newColor[2]), alpha: 1)
            //color = UIColor.yellow
        }
        color.setFill()
        color.setStroke()
        let circle : UIBezierPath = UIBezierPath(ovalIn :CGRect(x: 0, y: 0, width: 50, height: 50))
        circle.fill()
        let path: UIBezierPath = UIBezierPath()
        path.lineWidth = 5
        path.move(to: CGPoint(x: 0, y: 25))
        path.addLine(to: CGPoint(x: self.bounds.width, y: 25))
        path.stroke()
        
    }
    
    
}
