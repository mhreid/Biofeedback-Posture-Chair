//
//  ViewController.swift
//  Biofeedback Posture Chair
//
//  Created by Micah Reid on 10/18/16.
//  Copyright © 2016 Micah Reid. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var graph: Graph!
    @IBOutlet weak var topSpine: SpineIndicator!
    var timer = Timer()
    @IBOutlet weak var midSpine: SpineIndicator!
    @IBOutlet weak var bottomSpine: SpineIndicator!
    override func viewDidLoad() {
        
        super.viewDidLoad()
        timer = Timer.scheduledTimer(timeInterval: 1, target:self, selector: #selector(updateGraph), userInfo: nil, repeats: true)
                
    }
    func updateGraph(){
        graph.setNeedsDisplay()
        self.topSpine.setNeedsDisplay()
        self.midSpine.setNeedsDisplay()
        self.bottomSpine.setNeedsDisplay()

        print("test")
        let requestUrl : NSURL = NSURL(string: "http://www.midpointz.com:8080/GetGraph")!
        let urlRequest :NSMutableURLRequest = NSMutableURLRequest(url: requestUrl as URL)
        let session = URLSession.shared
        let task = session.dataTask(with: urlRequest as URLRequest){
            (data, response, error) -> Void in
            
            let httpResponse = response as! HTTPURLResponse
            let statusCode = httpResponse.statusCode
            
            if (statusCode == 200){
                do{
                    
                    let json = try JSONSerialization.jsonObject(with: data!, options:.allowFragments) as! [String:AnyObject]
                    
                    let sensor1 = (json["sensor1"] as? NSNumber)?.doubleValue
                    let sensor2 = (json["sensor2"] as? NSNumber)?.doubleValue
                    let sensor3 = (json["sensor3"] as? NSNumber)?.doubleValue
                    let averageReading = (sensor1! + sensor2! + sensor3!) / 3
                    print(averageReading)
                    self.graph.data.append(averageReading)
                    self.topSpine.value = sensor1!
                    self.midSpine.value = sensor2!
                    self.bottomSpine.value = sensor3!

                } catch {
                    print("Error with Json: \(error)")
                }
                
            }
        }
        task.resume()
        
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

